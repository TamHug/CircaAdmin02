from flask_login import  login_required, logout_user, current_user, login_user, login_manager, LoginManager, AnonymousUserMixin
from flask import Flask, render_template, request, url_for, redirect, logging, session, flash
from werkzeug.security import generate_password_hash, check_password_hash
from flask_sqlalchemy import SQLAlchemy
import pymysql
#from dB import DB

#pymysql.install_as_MySQLdb()


app = Flask(__name__)

login_manager = LoginManager(app)


# SQLITE Database



app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///circaAdmin.db' #creating the circa admin database


#app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

app.config['SECRET_KEY'] = "secret_key"

db = SQLAlchemy(app)  # initialiseing the database
app.app_context().push()


#Creating the model for the database - Orchard Table
class orchard_admin(db.Model):
    OR_ID = db.Column(db.Integer, primary_key=True, autoincrement=True) #creating a new column
    OR_Name = db.Column(db.String(100), nullable=False, unique=True) #data type and specifics within ()
    OR_Owner = db.Column(db.String(50), nullable=False )
    OR_Location = db.Column(db.String(150), nullable=False)
    OR_AdminUN = db.Column(db.String(50), nullable=False, unique=True )
    OR_AdminPW = db.Column(db.String(50), nullable=False)
    OR_ADPhone = db.Column(db.String(13), nullable=False)
    OR_ADName = db.Column(db.String(50), nullable=False )

#Creating the model for the database - Employee Table
class orchard_employee(db.Model):
    EM_ID = db.Column(db.Integer, primary_key=True)
    EM_Name = db.Column(db.String(50), nullable=False )
    EM_Phone = db.Column(db.String(13), nullable=False)
    EM_Position = db.Column(db.String(50), nullable=False )
    EM_Team = db.Column(db.String(50), nullable=False )
    EM_Manager = db.Column(db.String(50), nullable=False )
    OR_id = db.Column(db.Integer, db.ForeignKey('orchard_admin.OR_ID'))

    #creating a string
    def __repr__(self):
        return '<Name %r>' % self.name
    
db.create_all()
 




@login_manager.user_loader
def load_user(OR_ID):
    return orchard_admin.query.get(int(OR_ID))

class Anonymous(AnonymousUserMixin):
  def __init__(self):
    self.username = 'Guest'


@app.route('/')
def mainP():
    
    return render_template('firstP.html')  # Display a basic home page that users can either go to info or log in


@app.route('/moreInfo')
def moreInfo():
    
    return render_template('infoP.html')  # Display a page with basic information regarding Circa 

@app.route('/admCircaHome')
def admCircaHome():
   orchards = orchard_admin.query.order_by(orchard_admin.OR_Name).all()
   return render_template('circaAdminHome.html', orchard = orchards)




@app.route('/orEmployee')
def orEmployee(id1):
    return render_template('orEmployee.html')

@app.route('/login', methods=["POST", "GET"])
def login():
    error = None

    if request.method == "POST":

        username = request.form.get("username")
        password = request.form.get("password")      

        users = orchard_admin.query.filter_by(OR_AdminUN=username).first()

        if username == "Admin" and password == "Admin":
             
         orchards = orchard_admin.query.order_by(orchard_admin.OR_Name).all()
         return render_template('circaAdminHome.html', orchard = orchards)
        if users:
            if not users.OR_AdminPW == password:
             return redirect(url_for('login'))
            
            id1 = orchard_admin.query.filter(orchard_admin.OR_ID == users.OR_ID).all()
            return render_template('orAdminHome.html',ids = id1)

        
    return render_template('login.html')

@app.route('/add_orchard', methods=["POST", "GET"])
def add_orchard():
      if request.method == "POST":
             ID =  "001"
             Name = request.form.get("ORname")
             Owner = request.form.get("owner")
             Location = request.form.get("location")
             AdminUN = request.form.get("admUN")
             AdminPW = request.form.get("admPw")
             ADPhone = request.form.get("admPhone")
             ADName = request.form.get("admName")
             new_orchard = orchard_admin(OR_ID=ID, OR_Name=Name, OR_Owner=Owner, OR_Location=Location, OR_AdminUN=AdminUN, OR_AdminPW=AdminPW, OR_ADPhone=ADPhone, OR_ADName=ADName)
             db.session.add(new_orchard)
             db.session.commit()
             flash('New orchard added')
             orchards = orchard_admin.query.order_by(orchard_admin.OR_Name).all()
             return render_template('circaAdminHome.html', orchard = orchards)
      else:
          orchards = orchard_admin.query.order_by(orchard_admin.OR_Name)
          return render_template('addOR.html', orchard=orchards)
   
   
@app.route("/delete/<int:id>")
def delete(id):
    orchard_to_delete = orchard_admin.query.get_or_404(id)  # the id of Contact is used to identify which to delete
    db.session.delete(orchard_to_delete)  # information of user id to delete sent
    db.session.commit()

    orchards = orchard_admin.query.order_by(orchard_admin.OR_Name).all()
    return render_template('CircaAdminHome.html', orchard = orchards)

@app.route("/update/<int:id>", methods=["POST", "GET"])
def update(id):
   if request.method == 'POST':
       orUpdate = orchard_admin.query.get(id)
       orUpdate.OR_Name=request.form.get("ORname")
       orUpdate.OR_Owner=request.form.get("owner")
       orUpdate.OR_Location=request.form.get("location")
       orUpdate.OR_AdminUN=request.form.get("admUN")
       orUpdate.OR_AdminPW=request.form.get("admPw")
       orUpdate.OR_ADPhone=request.form.get("admPhone")
       orUpdate.OR_ADName=request.form.get("admName")
       db.session.commit()    
       return redirect(url_for('admCircaHome'))
   else:
        Updated = orchard_admin.query.get(id)
        return render_template('updateOR.html', orchard_to_update = Updated)




@app.route('/logout')
def logout():
    logout_user()  # logs out the current user and sends them to login
    return redirect(url_for('mainP'))


if __name__ == "__main__":
    app.run(debug=True)
     # app.run(debug=True, port=3306 , threaded=True)